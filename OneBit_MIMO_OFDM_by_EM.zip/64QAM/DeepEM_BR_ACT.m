function [sccc,f,ebr] = DeepEM_BR_ACT(yb_ob,Hw,sigma,N,W,K,S)
%% DeepEM_BR_HOT for one-bit resolution detection

load('Deep_para/parameters_64QAM_N128K6W256_L20_ACT.mat')
squareW = W^0.5;
HTHw = cell(W);
sc = zeros(K,W); + 1i*zeros(K,W);
sc_old = sc;
f = 0;
ebr=0;
sigma = sigma/squareW;
for i=1:W
    Hw{i} = Hw{i}/squareW;
    HTHw{i} = Hw{i}'*Hw{i};
end

%------------------------------------------------%
for epoch=1:20
    
    
    for i=1:W
        z(:,i) = Hw{i}*sc(:,i);
    end
    z = (ifft(z.')*squareW).';

%---------------E-step---------------------------------%
    r_R = real(z) + real(yb_ob) .* exp(-real(z).*real(z)/(2*sigma^2)) ./ (normcdf(real(z).*real(yb_ob)/sigma)+0.1^10) * (sigma+epsi0(epoch)) / (2*pi)^0.5 ;
    r_I = imag(z) + imag(yb_ob) .* exp(-imag(z).*imag(z)/(2*sigma^2)) ./ (normcdf(imag(z).*imag(yb_ob)/sigma)+0.1^10) * (sigma+epsi0(epoch)) / (2*pi)^0.5 ;
    r = r_R + 1i*r_I;
    r_tilde = (fft(r.')/squareW).';
%------------------------------------------------%


%----------------M-step----------------------%
    p1 = sc + alpha0(epoch)*(sc-sc_old);
    sc_old = sc;
    for i=1:W
        y = r_tilde(:,i);
        p2(:,i) = p1(:,i) - HTHw{i}*p1(:,i)*eta0(epoch) + Hw{i}'*y*eta0(epoch);  
    end
    sc = Extended_Sigmoid(real(p2),10*tau0(epoch)) + 1i * Extended_Sigmoid(imag(p2),10*tau0(epoch));
%------------------------------------------------%

end

sc = sc / norm(sc,'fro') * (K*W*42)^0.5;
sccc = ROUND(real(sc)) + 1i * ROUND(imag(sc));
ebr = sum(sum(sccc~=permute(S,[2,1])));

end

