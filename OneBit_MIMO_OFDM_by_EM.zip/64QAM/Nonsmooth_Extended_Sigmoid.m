function Y = Nonsmooth_Extended_Sigmoid(X,tau)
[m,n] = size(X);
y = zeros(m,n);
for i=1:m
    for j=1:n
        if X(i,j)<-5
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)+6)))-1+-6;
        end 
        if X(i,j)>-5 & X(i,j)<-3
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)+4)))-1+-4;
        end 
        if X(i,j)>-3 & X(i,j)<-1
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)+2)))-1+-2;
        end 
        if X(i,j)>-1 & X(i,j)<1
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)+0)))-1+0;
        end 
        if X(i,j)>1 & X(i,j)<3
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)-2)))-1+2;
        end 
        if X(i,j)>3 & X(i,j)<5
            Y(i,j) = 2./(1+exp(-tau*(X(i,j))-4))-1+4;
        end 
        if X(i,j)>5 
            Y(i,j) = 2./(1+exp(-tau*(X(i,j))-4))-1+6;
        end 

    end
end
end

