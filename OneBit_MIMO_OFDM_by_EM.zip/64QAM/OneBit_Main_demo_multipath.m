%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program performs testing for the EM_BR and unfolded networks in the following paper
% 
% The demo is for one-bit MIMO-OFDM detection with multipath channels on 64QAM.
% The demo loads the parameters of successfully trained DeepEM-BR-ACT networks.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;

maxTrial = 100;  % no. of trials

% MIMO-OFDM system setting:
% K is the number of single-antenna users, 
% N is the number of receive antennas,
% W is the number of subcarriers
% For each case, we load the parameters of unfolded networks

%% parameters
% [N,K,W] = [128,6,256], [256,12,512]
N = 128;           % N antennas in base station
K = 6;            % K users
W = 256;           % W carriers
L = 16;            % L the number of channel taps
eta=4;             % eta the number of paths
dlambda = 0.5;
SNR = 0:5:20;
BER = zeros(10,length(SNR));
RUN_TIME = zeros(10,length(SNR));

for snr=1:length(SNR)
    for trial=1:maxTrial
        
        %  produce channels and signals
        [yb, yb_ob, Hw, sigma, S] = produce_data(N,K,W,L,eta,dlambda,SNR(snr));
      
        t1 = clock;
        [sc,ebr1] = ZF_C(yb_ob,Hw,N,W,K,S);
        t2 = clock;
        T1 = etime(t2,t1);
       
        t1 = clock;
        [sc,f2,ebr2] = EM_BR_multistep(yb_ob,Hw,sigma,N,W,K,S);
        t2 = clock;
        T2 = etime(t2,t1);       
        
        t1 = clock;
        [sc,f3,ebr3] = DeepEM_BR_ACT(yb_ob,Hw,sigma,N,W,K,S);
        t2 = clock;
        T3 = etime(t2,t1);

     
        BER(1,snr) = BER(1,snr) + ebr1(end);
        BER(2,snr) = BER(2,snr) + ebr2(end);
        BER(3,snr) = BER(3,snr) + ebr3(end);
        RUN_TIME(1,snr) = RUN_TIME(1,snr) + T1(end);
        RUN_TIME(2,snr) = RUN_TIME(2,snr) + T2(end);
        RUN_TIME(3,snr) = RUN_TIME(3,snr) + T3(end);

   
end
end


H1 = figure
semilogy(SNR,BER(1,:)/(W*K*maxTrial),'-r', 'Linewidth',1.5,'markers',7);hold on;
semilogy(SNR,BER(2,:)/(W*K*maxTrial),'-+c', 'Linewidth',1.5,'markers',7);hold on;
semilogy(SNR,BER(3,:)/(W*K*maxTrial),'-vb', 'Linewidth',1.5,'markers',7);hold on;

xlabel('\fontsize{14}SNR (dB)')
ylabel('\fontsize{14}Bit Error Rate (BER)')
legend('\fontsize{12}ZF, one-bit','\fontsize{12}BOXEM', '\fontsize{12}DeepSIPGEM')
axis([0,20,1e-5,1])
hold on
grid on
set(gca,'FontSize',14)