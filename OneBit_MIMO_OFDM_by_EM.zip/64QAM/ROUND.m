function y = ROUND(x)
[m n]=size(x);
y = zeros(m,n);
for i=1:m
    for j=1:n
       if(x(i,j)>=6) y(i,j) = 7; end;
       if(x(i,j)>=4 & x(i,j)<6) y(i,j) = 5; end;
       if(x(i,j)>=2 & x(i,j)<4) y(i,j) = 3; end;
       if(x(i,j)>=0 & x(i,j)<2) y(i,j) = 1; end;
       if(x(i,j)>=-2 & x(i,j)<0) y(i,j) = -1; end;
       if(x(i,j)>=-4 & x(i,j)<-2) y(i,j) = -3; end;
       if(x(i,j)>=-6 & x(i,j)<-4) y(i,j) = -5; end;
       if(x(i,j)<-6) y(i,j) = -7; end;
    end
end
end