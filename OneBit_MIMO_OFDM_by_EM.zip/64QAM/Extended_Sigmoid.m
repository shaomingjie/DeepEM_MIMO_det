function Y = Extended_Sigmoid(X,tau)
Y = 2./(1+exp(-tau*(X+6))) + 2./(1+exp(-tau*(X+4))) + 2./(1+exp(-tau*(X+2))) + 2./(1+exp(-tau*(X)))+ 2./(1+exp(-tau*(X-6))) + 2./(1+exp(-tau*(X-4))) + 2./(1+exp(-tau*(X-2)))-7;
end

