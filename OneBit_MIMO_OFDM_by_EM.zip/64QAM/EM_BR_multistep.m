function [sc,f,ebr] = EM_BR_multistep(yb_ob,Hw,sigma,N,W,K,S)
%% EM_BR_multistep for one-bit resolution detection

sigma = sigma+0.5;
squareW = W^0.5;
HTHw = cell(W);
sc = zeros(K,W) + 1i*zeros(K,W);
f = 0;
ebr=0;
alpha0 = [0 0.0964 0.1699 0.2283 0.2761];
for i=1:W
    HTHw{i} = Hw{i}'*Hw{i};
    Lip(i) = norm(HTHw{i},2);
end

%------------------------------------------------%

epsi = 1; epoch=1;
while( epoch<=1000 && epsi>10^(-4))
    
    sc_old = sc;
    for i=1:W
        z(:,i) = Hw{i}*sc(:,i);
    end
    z = (ifft(z.')*squareW).';  
%     pp0_R = real(z).*real(yb_ob)/sigma;
%     pp0_I = imag(z).*imag(yb_ob)/sigma;
%     f(epoch) = (-1)*sum(sum(log(normcdf(pp0_R).*normcdf(pp0_I))));

%-----------E-step--------------------%
    r_R = real(z) + real(yb_ob) .* exp(-real(z).*real(z)/(2*sigma^2)) ./ (normcdf(real(z).*real(yb_ob)/sigma)+0.1^10) * sigma / (2*pi)^0.5 ;
    r_I = imag(z) + imag(yb_ob) .* exp(-imag(z).*imag(z)/(2*sigma^2)) ./ (normcdf(imag(z).*imag(yb_ob)/sigma)+0.1^10) * sigma / (2*pi)^0.5 ;
    r = r_R + 1i*r_I;
    r_tilde = (fft(r.')/squareW).';
%--------------------------------------%


%-----------M-step--------------------%
    sc_pre = sc;
    for i=1:W
        Hwy(:,i) = Hw{i}'*r_tilde(:,i)/Lip(i);  
    end
    for i_APG=1:5
        p1 = sc + alpha0(i_APG)*(sc-sc_pre);
        sc_pre = sc;
        for i=1:W 
            temp(:,i) = HTHw{i}*p1(:,i)/Lip(i) ;  
        end
    
        p2 = p1 - temp + Hwy;

        sc = min(max(real(p2),-7),7) + 1i * min(max(imag(p2),-7),7);
        if norm(sc-sc_pre,'fro')/norm(sc_pre,'fro')<0.001
            break
        end
    end
%--------------------------------------%

    epsi = norm(sc-sc_old,'fro') / norm(sc_old,'fro');
    epoch = epoch+1;
end

sc = sc / norm(sc,'fro') * (K*W*42)^0.5;
sccc = ROUND(real(sc)) + 1i * ROUND(imag(sc));
ebr = sum(sum(sccc~=permute(S,[2,1])));

end

