function Y = Nonsmooth_Extended_Sigmoid(X,tau)
[m,n] = size(X);
y = zeros(m,n);
for i=1:m
    for j=1:n
        if X(i,j)<-1
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)+2)))-3;
        end 
        if -1<X(i,j) & X(i,j)<1
            Y(i,j) = 2./(1+exp(-tau*(X(i,j))))-1;
        end 
        if X(i,j)>1
            Y(i,j) = 2./(1+exp(-tau*(X(i,j)-2)))+1;
        end 
    end
end
end

