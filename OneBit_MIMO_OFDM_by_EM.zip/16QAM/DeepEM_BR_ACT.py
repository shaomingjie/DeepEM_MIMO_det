

import numpy as np
import pickle
import glob
import random
import yaml
import copy 
from sklearn.utils import shuffle
import itertools
from src.functions_asc import *

import torch
import torch.nn as nn
from torch.autograd import Variable
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
import scipy
import scipy.io as io
from scipy.stats import norm


#==============================================
# Hyper Parameters
#==============================================

#  [N,K,W] = [128,10,256], [256,20,512]

hyper_params =  {               'EPOCH': 100000,                            
                                'BATCH_SIZE': 100,                     
                                'N': 128,     
                                'K': 10,        
                                'W': 256,        
                                'L': 16,        
                                'eta': 4,        
                                'dlambda': 0.5,        
                                'LAYER_NUMBER': 20,
                                'LR': 1e-3,                             
                                'WEIGHT_DECAY_COEFFICIENT': 0.0015,
                                'SNR': 10
                            }
                            
EPOCH = hyper_params['EPOCH']
BATCH_SIZE = hyper_params['BATCH_SIZE']
K = hyper_params['K'] 
N = hyper_params['N']   
W = hyper_params['W']  
L = hyper_params['L']  
eta = hyper_params['eta']
dlambda = hyper_params['dlambda']    
LAYER_NUMBER = hyper_params['LAYER_NUMBER']              
LR = hyper_params['LR']         
WEIGHT_DECAY_COEFFICIENT = hyper_params['WEIGHT_DECAY_COEFFICIENT'] 
SNR = hyper_params['SNR'] 

Pi = np.pi
F = scipy.fft(scipy.eye(W)) / np.power(W, 0.5)
FF = np.zeros((2*W,2*W))
FF[0:W,0:W] =  np.real(F)
FF[0:W,W:2*W] =  (-1)*np.imag(F)
FF[W:2*W,0:W] =  np.imag(F)
FF[W:2*W,W:2*W] =  np.real(F)
EEE = np.power(0.1, 10)
gpu = 0

#==============================================
#Produce data 
#==============================================
print('Loading Data . ')

def load_data(N,K,W,L,eta,dlambda,Pi):
    theta = np.random.rand(L,K,eta)*2*Pi - Pi
    beta = np.random.randn(L,K,eta) / np.power(2*eta, 0.5) + np.random.randn(L,K,eta) / np.power(2*eta, 0.5) *1j
    a = np.array(np.zeros((L,K,eta,N)),dtype = "complex_")
    for i in range(L):
        for j in range(K):
            for k in range(eta):
                for n in range(N):
                    a[i,j,k,n] = np.exp((-2j)*Pi*dlambda*n*np.sin(theta[i,j,k]))
    h = np.array(np.zeros((L,K,N)),dtype = "complex_")
    for i in range(L):
        for j in range(K):
            temp = np.array(np.zeros((N,1)),dtype = "complex_")
            for k in range(eta):
                temp[:,0:1] = temp[:,0:1] + a[i,j,k:k+1,:].transpose()*beta[i,j,k]   
            h[i,j:j+1,:] = temp.transpose()
    Hw = np.array(np.zeros((W,N,K)),dtype = "complex_")
    for i in range(W):
        temp = np.array(np.zeros((N,K)),dtype = "complex_")
        for j in range(L):
            temp = temp + h[j].transpose()*np.exp(-2j*Pi/W*(j)*(i-W/2.0))
        temp = temp / np.power(W, 0.5)
        Hw[i] = temp
    Hb = np.array(np.zeros((N,W,K)),dtype = "complex_")
    for i in range(N):
        Hb[i] = Hw[:,i,:]
    HHw = np.zeros((W,2*N,2*K))
    for i in range(W):
        HHw[i,0:N,0:K] =  np.real(Hw[i])
        HHw[i,0:N,K:K*2] =  np.imag(Hw[i])*(-1)
        HHw[i,N:N*2,0:K] =  np.imag(Hw[i])
        HHw[i,N:N*2,K:K*2] =  np.real(Hw[i])
    HHb = np.zeros((N,2*W,2*K))
    for i in range(N):
        HHb[i,0:W,0:K] =  np.real(Hb[i])
        HHb[i,0:W,K:K*2] =  np.imag(Hb[i])*(-1)
        HHb[i,W:W*2,0:K] =  np.imag(Hb[i])
        HHb[i,W:W*2,K:K*2] =  np.real(Hb[i])
    
    S = (np.random.random_integers(0, 3, size=[W,K])*2-3) + 1j*(np.random.random_integers(0, 3, size=[W,K])*2-3)
    zb = np.array(np.zeros((N,W)),dtype = "complex_")
    for i in range(N):
        for j in range(W):
            zb[i,j] = np.vdot(Hb[i,j,:].conj() , S[j,:].transpose())
    sigma_max = np.power(10*K*0.5/W, 0.5) * np.power(0.1,  (-5)/ 20)
    sigma_min = np.power(10*K*0.5/W, 0.5) * np.power(0.1,  (17)/ 20)
    sigma = np.random.rand()*(sigma_max-sigma_min) + sigma_min
    print('sigma_min',sigma_min, 'sigma_max',sigma_max, 'sigma',sigma)
    yb = np.matmul(zb,np.conj(F)) + sigma * np.random.randn(N,W) + 1j * sigma * np.random.randn(N,W)
    yb_ob = np.sign(np.real(yb)) + 1j * np.sign(np.imag(yb))
    return yb, yb_ob, Hw, HHw, Hb, HHb, sigma, S

def data_process(yb_ob, HHw, HHb, sigma, S, N, W, K):
    yb_ob_r = np.zeros((N,2*W))
    yb_ob_r[:,0:W] = np.real(yb_ob)
    yb_ob_r[:,W:W*2] = np.imag(yb_ob)
    S_r = np.zeros((W,2*K))
    S_r[:,0:K] = np.real(S)
    S_r[:,K:K*2] = np.imag(S)
    return torch.from_numpy(yb_ob_r), torch.from_numpy(HHw), torch.from_numpy(HHb), sigma, torch.from_numpy(S_r)






#==============================================
#MODEL 
#==============================================
print('Initialize Model Structure. ')

class MIMO_BR_OB_R(nn.Module):
    def __init__(self, FF, W, N, K, BATCH_SIZE, LAYER_NUMBER):
        super(MIMO_BR_OB_R, self).__init__()
        self.FF = FF
        self.W = W
        self.N = N
        self.K = K
        self.BATCH_SIZE = BATCH_SIZE
        self.E = torch.ones(W,2*K).double()*3
        self.NE = (-3)*torch.ones(W,2*K).double()
        self.LAYER_NUMBER = LAYER_NUMBER
        self.norm = torch.distributions.normal.Normal(torch.tensor([0.0]).double(), torch.tensor([1.0]).double())
        
        self.eta = torch.nn.Parameter(torch.ones(LAYER_NUMBER).double()*0.001, requires_grad = True)
        self.tau = torch.nn.Parameter(torch.ones(LAYER_NUMBER).double()*0.1, requires_grad = True)
        self.epsi = torch.nn.Parameter(torch.ones(LAYER_NUMBER).double()*0.1, requires_grad = True)
        self.alpha = torch.nn.Parameter(torch.ones(LAYER_NUMBER).double()*0.001, requires_grad = True)

    def ACT(self, X, tau):
        return 2/(1+torch.exp(-(X-2)*tau))+2/(1+torch.exp(-(X)*tau))+2/(1+torch.exp(-(X+2)*tau))-3
    
    def forward(self, yb_ob_r, HHw, HHb, sigma, S):
        io.savemat('parameters_16QAM_L20_ACT.mat', {'eta0': self.eta.data.cpu().numpy(), 'tau0': self.tau.data.cpu().numpy(), 'epsi0': self.epsi.data.cpu().numpy(), 'alpha0': self.alpha.data.cpu().numpy()})

        s = torch.zeros(self.W,2*self.K).double()
        s_old = s.clone()
        z = torch.zeros((self.N,2*self.W)).double()
        z = torch.cat((torch.sum(HHb[:,0:self.W,:] * s,2), torch.sum(HHb[:,self.W:self.W*2,:] * s,2)), 1)
        z = torch.matmul(z,self.FF)

        for epoch in range(LAYER_NUMBER):

            r = z + yb_ob_r / np.power(2*Pi, 0.5) * torch.exp((-1)*z*z/(2*sigma*sigma)) / (self.norm.cdf(z*yb_ob_r/sigma)+EEE) * (sigma+self.epsi[epoch])
            r_tilde = torch.matmul(r,self.FF.permute(1,0))
            r_tildew = torch.zeros(2*self.N,self.W).double()
            t1, t2 = torch.split(r_tilde, self.W, dim = 1)
            r_tildew = torch.cat((t1, t2), 0)

            yr = r_tildew.permute(1,0).unsqueeze(1)
            p1 = s + self.alpha[epoch]*(s-s_old)
            s_old = s.clone()
            p2 = p1 - ( torch.squeeze(torch.matmul(torch.matmul(p1.unsqueeze(1), HHw.permute(0,2,1))-yr,HHw)) )* self.eta[epoch]
            s = self.ACT(p2, 10*self.tau[epoch])
            z = torch.cat((torch.sum(HHb[:,0:self.W,:] * s,2), torch.sum(HHb[:,self.W:self.W*2,:] * s,2)), 1)
            z = torch.matmul(z,self.FF)

        return s



# This is used to decide whether a pretrained model is used.
FLAG_use_pretrained_model = True
pretrained_model_path = 'myModel_20_ACT.dict'
    



MyModel = MIMO_BR_OB_R(torch.from_numpy(FF), W, N, K, BATCH_SIZE, LAYER_NUMBER)
# MyModel.cuda(gpu)
params = MyModel.parameters()
MMM = list(MyModel.parameters())
print(len(MMM))
for param in MMM:
    print(param.size())


print(params)
optimizer = torch.optim.Adam(params, lr=LR)  
loss_func = nn.MSELoss(size_average=False).double() 

# use pretrained model
# if FLAG_use_pretrained_model == True:
#   MyModel.load_state_dict(torch.load(pretrained_model_path))


#==============================================
#Model Training
#==============================================
print('Start Model Training. ')

train_loss = torch.zeros(EPOCH)

step = 0 
print('Here is 1. ')
for epoch in range(EPOCH):

        
        yb, yb_ob, Hw, HHw, Hb, HHb, sigma, S = load_data(N,K,W,L,eta,dlambda,Pi)
        yb_ob_r, HHw, HHb, sigma, S_r = data_process(yb_ob, HHw, HHb, sigma, S, N, W, K)
        output = MyModel(yb_ob_r, HHw, HHb, sigma, S_r)
        loss = loss_func(output , S_r) 

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


        train_loss[epoch] = loss.data 
       

        if epoch % 1 == 0:

            torch.save(MyModel.state_dict(), 'myModel_20_ACT.dict')
            io.savemat('train_loss_20_ACT.mat', {'train_loss': train_loss.numpy()})
            print('Epoch:%d' % epoch, '| TrainLoss: %.6f' % (train_loss[epoch].numpy()))

