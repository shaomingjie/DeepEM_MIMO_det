function [sc,ebr] = ZF_C(yb_ob,Hw,N,W,K,S)
%% ZF for one-bit resolution detection

squareW = W^0.5;
yb_ob_tilde = (fft(yb_ob.')/squareW).';

for i=1:W
    yr = yb_ob_tilde(:,i);
    HH = Hw{i};
    sc(i,:) = (HH'*HH)^(-1)*HH'*yr;
end

sc = sc / norm(sc,'fro') * (K*W*10)^0.5;
sc = ROUND(real(sc)) + 1i * ROUND(imag(sc));
ebr = sum(sum(sc~=S));
end
