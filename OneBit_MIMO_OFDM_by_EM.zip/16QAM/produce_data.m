function [yb, yb_ob, Hw, sigma, S] = produce_data(N,K,W,L,eta,dlambda,SNR)
%% Produce data for MIMO-OFDM under 16QAM and multipath channel
% theta(L,K,eta)  real
% eta(L,K,eta)    complex
% a(L,K,eta,N)    complex
% h(L,K,N)        complex 
% Hw(W,N,K)       complex
% Hb(N,W,K)       complex Hb(n,:,k) = h_tilde(n,k)
% F(W,W)          complex the (unitary) W-point DFT matrix
% S(W,K)          complex transmitted signals 
% yb(N,W)         complex received full-resolution signals
% yb_ob(N,W)      complex received one-bit quantized signals
% sigma           real NC(0,2*sigma^2)

theta = rand(L, K, eta)*2*pi-pi;         
beta = randn(L, K, eta) * (0.5 / eta)^0.5 + randn(L, K, eta) * (0.5 / eta)^0.5 * 1i;     
for i=1:L
    for j=1:K
        for k=1:eta
            for n=1:N
            a(i,j,k,n) = exp(-1i*2*pi*dlambda*(n-1)*sin(theta(i,j,k)));
            end
        end
    end
end

h = cell(L);
for i=1:L
    for j=1:K
        temp = zeros(N,1);
        for k=1:eta
            temp = temp + squeeze(a(i,j,k,:)) * beta(i,j,k);
        end
        hh(j,:) = temp;
    end
    h{i} = hh;
end

Hw = cell(W,1);
for i=1:W
    temp = zeros(N,K);
    for j=1:L
        temp = temp + permute(h{j},[2,1]) * exp(-1i*2*pi/W*(j-1)*(i-1));
    end
    temp = temp;
    Hw{i} = temp;
end

squareW = W^0.5;
S = (randi(4,W,K)*2-5) + 1i * (randi(4,W,K)*2-5);

for i=1:W
zb(:,i) = Hw{i}*permute(S(i,:),[2,1]);
end

P = 10;
sigma = (P*K/(2))^0.5 * 0.1^(SNR/20);
noise = sigma*randn(N,W) + sigma*1i*randn(N,W);
yb_clear = (ifft(zb.')*squareW).';
yb = yb_clear + noise;
yb_ob = sign(real(yb)) + 1i*sign(imag(yb));

end

